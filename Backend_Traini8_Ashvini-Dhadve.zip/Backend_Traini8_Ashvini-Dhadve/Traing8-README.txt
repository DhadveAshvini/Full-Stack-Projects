


Step 1: Set Up Your Development Environment

 * Install Java Development Kit (JDK):
Download and install the latest version of JDK from the Oracle website or use a package manager.
Ensure that Java is properly configured in your system environment variables.


* Choose an IDE:
Select an Integrated Development Environment (IDE) for Java development. Options include IntelliJ IDEA, Eclipse, or Spring Tool Suite (STS).
Download and install your preferred IDE.

Step 2: Create a New Spring Boot Project

* Using Spring Initializr:

Go to https://start.spring.io/.

Set the project metadata (Group, Artifact, Name, and Package).
Add dependencies: Spring Web, Spring Data JPA, and any other dependencies you may need.
Click "Generate" to download the project as a ZIP file.

Using IDE (Alternative):
Open your IDE.
Choose to create a new project and select "Spring Initializr".
Fill in the project details and select the dependencies mentioned above.

i> extract zip folder
ii> open in any IDE like STS or eclipse or any other u want
  
Here i am showing u about sts how can u add or open your maven project 

For That choose option as file -> import -> maven -> existing maven project ->
Choose your extracted zip folder from directory --> Finish


iii> Change application.property files according your DB connection  

iv> Run project As Spring Boot App


Step 3: Define Entity and Repository

Define the TrainingCenter Entity:
Create a Java class named TrainingCenter with fields matching the provided requirements.

Add annotations such as @Entity, @Id, @NotBlank, @Size, @Email, @Pattern, etc., for validation and persistence.

Create an embedded class Address within TrainingCenter for the address details.

Create the TrainingCenterRepository:
Create an interface TrainingCenterRepository that extends JpaRepository<TrainingCenter, Long> to handle CRUD operations for the TrainingCenter entity.

Step 4: Implement Service Layer

Create the TrainingCenterService Class:

Create a service class TrainingCenterService to implement business logic.

Autowire the TrainingCenterRepository and use it to interact with the database.

Implement methods to save a new training center and retrieve all training centers.

Step 5: Implement Controller Layer

Create the TrainingCenterController Class:

Create a controller class TrainingCenterController to handle HTTP requests.
Autowire the TrainingCenterService.

Implement POST and GET mapping methods for creating and retrieving training centers.
Implement validation annotations (@Valid) for request body parameters.
Handle exceptions using @ExceptionHandler.

Step 6: Configure Application Properties

Configure Database Connection:
Set up database connection properties in application.properties or application.yml.
Configure properties for datasource URL, username, password, and dialect.

Step 7: Test Your APIs

* Test the POST API:

Use tools like Postman or curl to send a POST request with JSON data to create a new training center.
Ensure that validation works as expected for mandatory fields and that the createdOn field is populated automatically.

* Test the GET API:
Send a GET request to retrieve the list of all stored training centers.
Verify that the response is in JSON format and contains the expected data.
Here u can also Filter The List According to parameter -> 

Endpoint: http://localhost:8082/training-centers?centerName=Jspider&city=Banglore
 u can change parameter according to list u have 

Step 8: Run and Deploy Your Application
Run Your Spring Boot Application:
Run your Spring Boot application from your IDE or using Maven (mvn spring-boot:run)

Verify that the application starts without errors.
Deploy Your Application:
Deploy your Spring Boot application to your preferred environment, such as local servers, cloud platforms, or container orchestration platforms.