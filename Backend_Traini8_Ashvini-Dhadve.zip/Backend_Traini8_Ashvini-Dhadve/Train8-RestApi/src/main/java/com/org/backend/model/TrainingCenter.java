package com.org.backend.model;

import java.util.List;

import jakarta.persistence.Column;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.Embedded;
import jakarta.persistence.Entity;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.Size;

@Entity
@Table(name = "training-center")
public class TrainingCenter {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long id;

	@NotBlank(message = "CenterName is mandatory")
	@Size(max = 40, message = "CenterName must be less than 40 characters")
	private String centerName;

	@NotBlank(message = "CenterCode is mandatory")
	@Pattern(regexp = "[a-zA-Z0-9]{12}", message = "CenterCode must be exactly 12 alphanumeric characters")
	private String centerCode;

	@NotNull(message = "Address is mandatory")
	private Address address;

	@Positive(message = "Student Capacity must be a positive number")
	private int studentCapacity;

	@NotEmpty(message = "Courses Offered must not be empty")
	private List<String> coursesOffered;

	private long createdOn;

	@Email(message = "Invalid email format")
	private String contactEmail;

	@NotBlank(message = "ContactPhone is mandatory")
	private String contactPhone;

	public TrainingCenter(Long id,
			@NotBlank(message = "CenterName is mandatory") @Size(max = 40, message = "CenterName must be less than 40 characters") String centerName,
			@NotBlank(message = "CenterCode is mandatory") @Pattern(regexp = "[a-zA-Z0-9]{12}", message = "CenterCode must be exactly 12 alphanumeric characters") String centerCode,
			@NotNull(message = "Address is mandatory") Address address,
			@Positive(message = "Student Capacity must be a positive number") int studentCapacity,
			@NotEmpty(message = "Courses Offered must not be empty") List<String> coursesOffered, long createdOn,
			@Email(message = "Invalid email format") String contactEmail,
			@NotBlank(message = "ContactPhone is mandatory") String contactPhone) {
		super();
		this.id = id;
		this.centerName = centerName;
		this.centerCode = centerCode;
		this.address = address;
		this.studentCapacity = studentCapacity;
		this.coursesOffered = coursesOffered;
		this.createdOn = createdOn;
		this.contactEmail = contactEmail;
		this.contactPhone = contactPhone;
	}

	public TrainingCenter() {
		super();

	}

	@Override
	public String toString() {
		return "TrainingCenter [id=" + id + ", centerName=" + centerName + ", centerCode=" + centerCode + ", address="
				+ address + ", studentCapacity=" + studentCapacity + ", coursesOffered=" + coursesOffered
				+ ", createdOn=" + createdOn + ", contactEmail=" + contactEmail + ", contactPhone=" + contactPhone
				+ "]";
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getCenterName() {
		return centerName;
	}

	public void setCenterName(String centerName) {
		this.centerName = centerName;
	}

	public String getCenterCode() {
		return centerCode;
	}

	public void setCenterCode(String centerCode) {
		this.centerCode = centerCode;
	}

	public Address getAddress() {
		return address;
	}

	public void setAddress(Address address) {
		this.address = address;
	}

	public int getStudentCapacity() {
		return studentCapacity;
	}

	public void setStudentCapacity(int studentCapacity) {
		this.studentCapacity = studentCapacity;
	}

	public List<String> getCoursesOffered() {
		return coursesOffered;
	}

	public void setCoursesOffered(List<String> coursesOffered) {
		this.coursesOffered = coursesOffered;
	}

	public long getCreatedOn() {
		return createdOn;
	}

	public void setCreatedOn(long createdOn) {
		this.createdOn = createdOn;
	}

	public String getContactEmail() {
		return contactEmail;
	}

	public void setContactEmail(String contactEmail) {
		this.contactEmail = contactEmail;
	}

	public String getContactPhone() {
		return contactPhone;
	}

	public void setContactPhone(String contactPhone) {
		this.contactPhone = contactPhone;
	}

}
