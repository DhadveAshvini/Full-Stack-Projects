package com.org.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Train8RestApiApplication {

	public static void main(String[] args) {
		SpringApplication.run(Train8RestApiApplication.class, args);
	}

}
