package com.org.backend.service;

import java.time.Instant;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.org.backend.model.TrainingCenter;
import com.org.backend.repository.TrainingCenterRepository;

@Service
public class TrainingCenterService {

	

	 @Autowired
	    private TrainingCenterRepository trainingCenterRepository;

	    public TrainingCenter createTrainingCenter(TrainingCenter trainingCenter) {
	    	     // genrating timestamp and adding in setCreatedOn ,not gernating manually
	        trainingCenter.setCreatedOn(Instant.now().getEpochSecond());
	        return trainingCenterRepository.save(trainingCenter);
	    }
           
	    public List<TrainingCenter> getAllTrainingCenters() {
	        return trainingCenterRepository.findAll();
	    }
	    
	    //filtering list api logic
	    public List<TrainingCenter> filterTrainingCenters(String centerName, String city) {
	        List<TrainingCenter> allTrainingCenters = trainingCenterRepository.findAll();

	        // Apply filters
	        if (centerName != null ){
	            allTrainingCenters = allTrainingCenters.stream()
	                    .filter(tc -> tc.getCenterName().toLowerCase().contains(centerName.toLowerCase()))
	                    .collect(Collectors.toList());
	        }

	        if (city != null ) {
	            allTrainingCenters = allTrainingCenters.stream()
	                    .filter(tc -> tc.getAddress().getCity().toLowerCase().contains(city.toLowerCase()))
	                    .collect(Collectors.toList());
	        }

	        return allTrainingCenters;
	    }
	    
	   
}
