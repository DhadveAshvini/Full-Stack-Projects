package com.org.backend.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.org.backend.model.TrainingCenter;

public interface TrainingCenterRepository  extends JpaRepository<TrainingCenter, Long>{

	List<TrainingCenter> findByAddressCity(String city);

}
