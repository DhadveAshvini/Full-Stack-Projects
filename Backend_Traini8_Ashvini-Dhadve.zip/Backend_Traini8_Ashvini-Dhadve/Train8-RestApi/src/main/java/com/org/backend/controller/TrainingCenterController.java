package com.org.backend.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.util.StringUtils;
import org.springframework.validation.BindingResult;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.org.backend.model.TrainingCenter;
import com.org.backend.service.TrainingCenterService;

import jakarta.validation.Valid;

@RestController
@RequestMapping("/training-centers")
public class TrainingCenterController {

	@Autowired
	private TrainingCenterService trainingCenterService;

	
	//creating 
	@PostMapping
	public ResponseEntity<?> createTrainingCenter(@Valid @RequestBody TrainingCenter trainingCenter,
			BindingResult result) {
		if (result.hasErrors()) {
			return ResponseEntity.badRequest().body("Validation error: " + result.getAllErrors());
		}
		TrainingCenter savedTrainingCenter = trainingCenterService.createTrainingCenter(trainingCenter);
		return ResponseEntity.status(HttpStatus.CREATED).body(savedTrainingCenter);
	}

	@GetMapping
	public ResponseEntity<?> getAllTrainingCenters(@RequestParam(required = false) String centerName,
			@RequestParam(required = false) String city) {
		List<TrainingCenter> trainingCenters;
		if (centerName == null && city == null) {
			trainingCenters = trainingCenterService.getAllTrainingCenters();
		} else {
			// Null check before invoking isEmpty()
			if (centerName != null) {
				centerName = centerName.trim().toLowerCase(); // Optional: normalize input
			}
			if (city != null) {
				city = city.trim().toLowerCase(); // Optional: normalize input
			}
			trainingCenters = trainingCenterService.filterTrainingCenters(centerName, city);
		}
		return new ResponseEntity<>(trainingCenters, HttpStatus.OK);
	}

	@ExceptionHandler
	public ResponseEntity<String> handleException(Exception e) {
		return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(e.getMessage());
	}

}